// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XINSERTIONSORT_H
#define XINSERTIONSORT_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xinsertionsort_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XInsertionsort_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XInsertionsort;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XInsertionsort_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XInsertionsort_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XInsertionsort_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XInsertionsort_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XInsertionsort_Initialize(XInsertionsort *InstancePtr, u16 DeviceId);
XInsertionsort_Config* XInsertionsort_LookupConfig(u16 DeviceId);
int XInsertionsort_CfgInitialize(XInsertionsort *InstancePtr, XInsertionsort_Config *ConfigPtr);
#else
int XInsertionsort_Initialize(XInsertionsort *InstancePtr, const char* InstanceName);
int XInsertionsort_Release(XInsertionsort *InstancePtr);
#endif

void XInsertionsort_Start(XInsertionsort *InstancePtr);
u32 XInsertionsort_IsDone(XInsertionsort *InstancePtr);
u32 XInsertionsort_IsIdle(XInsertionsort *InstancePtr);
u32 XInsertionsort_IsReady(XInsertionsort *InstancePtr);
void XInsertionsort_EnableAutoRestart(XInsertionsort *InstancePtr);
void XInsertionsort_DisableAutoRestart(XInsertionsort *InstancePtr);

void XInsertionsort_Set_arr(XInsertionsort *InstancePtr, u32 Data);
u32 XInsertionsort_Get_arr(XInsertionsort *InstancePtr);
void XInsertionsort_Set_n(XInsertionsort *InstancePtr, u32 Data);
u32 XInsertionsort_Get_n(XInsertionsort *InstancePtr);

void XInsertionsort_InterruptGlobalEnable(XInsertionsort *InstancePtr);
void XInsertionsort_InterruptGlobalDisable(XInsertionsort *InstancePtr);
void XInsertionsort_InterruptEnable(XInsertionsort *InstancePtr, u32 Mask);
void XInsertionsort_InterruptDisable(XInsertionsort *InstancePtr, u32 Mask);
void XInsertionsort_InterruptClear(XInsertionsort *InstancePtr, u32 Mask);
u32 XInsertionsort_InterruptGetEnabled(XInsertionsort *InstancePtr);
u32 XInsertionsort_InterruptGetStatus(XInsertionsort *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
