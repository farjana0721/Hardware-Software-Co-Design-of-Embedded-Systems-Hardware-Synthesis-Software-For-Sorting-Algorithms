// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XBUBBLE_H
#define XBUBBLE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xbubble_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XBubble_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XBubble;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XBubble_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XBubble_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XBubble_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XBubble_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XBubble_Initialize(XBubble *InstancePtr, u16 DeviceId);
XBubble_Config* XBubble_LookupConfig(u16 DeviceId);
int XBubble_CfgInitialize(XBubble *InstancePtr, XBubble_Config *ConfigPtr);
#else
int XBubble_Initialize(XBubble *InstancePtr, const char* InstanceName);
int XBubble_Release(XBubble *InstancePtr);
#endif

void XBubble_Start(XBubble *InstancePtr);
u32 XBubble_IsDone(XBubble *InstancePtr);
u32 XBubble_IsIdle(XBubble *InstancePtr);
u32 XBubble_IsReady(XBubble *InstancePtr);
void XBubble_EnableAutoRestart(XBubble *InstancePtr);
void XBubble_DisableAutoRestart(XBubble *InstancePtr);

void XBubble_Set_arr(XBubble *InstancePtr, u32 Data);
u32 XBubble_Get_arr(XBubble *InstancePtr);

void XBubble_InterruptGlobalEnable(XBubble *InstancePtr);
void XBubble_InterruptGlobalDisable(XBubble *InstancePtr);
void XBubble_InterruptEnable(XBubble *InstancePtr, u32 Mask);
void XBubble_InterruptDisable(XBubble *InstancePtr, u32 Mask);
void XBubble_InterruptClear(XBubble *InstancePtr, u32 Mask);
u32 XBubble_InterruptGetEnabled(XBubble *InstancePtr);
u32 XBubble_InterruptGetStatus(XBubble *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
