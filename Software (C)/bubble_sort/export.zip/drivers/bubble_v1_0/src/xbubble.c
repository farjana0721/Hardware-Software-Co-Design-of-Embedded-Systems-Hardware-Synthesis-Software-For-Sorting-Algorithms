// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xbubble.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XBubble_CfgInitialize(XBubble *InstancePtr, XBubble_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XBubble_Start(XBubble *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBubble_ReadReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XBubble_WriteReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XBubble_IsDone(XBubble *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBubble_ReadReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XBubble_IsIdle(XBubble *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBubble_ReadReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XBubble_IsReady(XBubble *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBubble_ReadReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XBubble_EnableAutoRestart(XBubble *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBubble_WriteReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XBubble_DisableAutoRestart(XBubble *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBubble_WriteReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_AP_CTRL, 0);
}

void XBubble_Set_arr(XBubble *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBubble_WriteReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_ARR_DATA, Data);
}

u32 XBubble_Get_arr(XBubble *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBubble_ReadReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_ARR_DATA);
    return Data;
}

void XBubble_InterruptGlobalEnable(XBubble *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBubble_WriteReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_GIE, 1);
}

void XBubble_InterruptGlobalDisable(XBubble *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBubble_WriteReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_GIE, 0);
}

void XBubble_InterruptEnable(XBubble *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XBubble_ReadReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_IER);
    XBubble_WriteReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_IER, Register | Mask);
}

void XBubble_InterruptDisable(XBubble *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XBubble_ReadReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_IER);
    XBubble_WriteReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XBubble_InterruptClear(XBubble *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBubble_WriteReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_ISR, Mask);
}

u32 XBubble_InterruptGetEnabled(XBubble *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XBubble_ReadReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_IER);
}

u32 XBubble_InterruptGetStatus(XBubble *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XBubble_ReadReg(InstancePtr->Control_BaseAddress, XBUBBLE_CONTROL_ADDR_ISR);
}

