// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xradixsort.h"

extern XRadixsort_Config XRadixsort_ConfigTable[];

XRadixsort_Config *XRadixsort_LookupConfig(u16 DeviceId) {
	XRadixsort_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XRADIXSORT_NUM_INSTANCES; Index++) {
		if (XRadixsort_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XRadixsort_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XRadixsort_Initialize(XRadixsort *InstancePtr, u16 DeviceId) {
	XRadixsort_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XRadixsort_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XRadixsort_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

