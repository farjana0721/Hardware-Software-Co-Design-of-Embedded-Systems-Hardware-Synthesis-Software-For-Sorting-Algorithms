// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XRADIXSORT_H
#define XRADIXSORT_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xradixsort_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XRadixsort_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XRadixsort;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XRadixsort_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XRadixsort_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XRadixsort_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XRadixsort_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XRadixsort_Initialize(XRadixsort *InstancePtr, u16 DeviceId);
XRadixsort_Config* XRadixsort_LookupConfig(u16 DeviceId);
int XRadixsort_CfgInitialize(XRadixsort *InstancePtr, XRadixsort_Config *ConfigPtr);
#else
int XRadixsort_Initialize(XRadixsort *InstancePtr, const char* InstanceName);
int XRadixsort_Release(XRadixsort *InstancePtr);
#endif

void XRadixsort_Start(XRadixsort *InstancePtr);
u32 XRadixsort_IsDone(XRadixsort *InstancePtr);
u32 XRadixsort_IsIdle(XRadixsort *InstancePtr);
u32 XRadixsort_IsReady(XRadixsort *InstancePtr);
void XRadixsort_EnableAutoRestart(XRadixsort *InstancePtr);
void XRadixsort_DisableAutoRestart(XRadixsort *InstancePtr);

void XRadixsort_Set_arr_i(XRadixsort *InstancePtr, u32 Data);
u32 XRadixsort_Get_arr_i(XRadixsort *InstancePtr);
u32 XRadixsort_Get_arr_o(XRadixsort *InstancePtr);
u32 XRadixsort_Get_arr_o_vld(XRadixsort *InstancePtr);

void XRadixsort_InterruptGlobalEnable(XRadixsort *InstancePtr);
void XRadixsort_InterruptGlobalDisable(XRadixsort *InstancePtr);
void XRadixsort_InterruptEnable(XRadixsort *InstancePtr, u32 Mask);
void XRadixsort_InterruptDisable(XRadixsort *InstancePtr, u32 Mask);
void XRadixsort_InterruptClear(XRadixsort *InstancePtr, u32 Mask);
u32 XRadixsort_InterruptGetEnabled(XRadixsort *InstancePtr);
u32 XRadixsort_InterruptGetStatus(XRadixsort *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
